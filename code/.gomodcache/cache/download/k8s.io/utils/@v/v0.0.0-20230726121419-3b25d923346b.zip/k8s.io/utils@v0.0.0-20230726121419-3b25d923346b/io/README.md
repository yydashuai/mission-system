# IO

This package provides interfaces for working with file IO. Currently it
provides functionality for consistently reading a file.
